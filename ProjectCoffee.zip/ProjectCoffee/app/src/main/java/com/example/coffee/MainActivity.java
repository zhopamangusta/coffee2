package com.example.coffee;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Это приложение отображает форму заказа для заказа кофе.
 */
public class MainActivity extends AppCompatActivity {

    int quantity = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Этот метод вызывается при нажатии кнопки заказа.
     */

    private int calculatePrice(boolean addWhippedCream, boolean addChocolate) {

        int basePrice = 5;
        if(addWhippedCream){
            basePrice = basePrice + 1 ;
        }
        if(addChocolate){
            basePrice = basePrice + 2;
        }
        return quantity * basePrice;
    }



    public void submitOrder(View view) {
        EditText nameOfCustomer = findViewById(R.id.NameClient_view);
        String name = nameOfCustomer.getText().toString();

        CheckBox caramelCheckBox= findViewById(R.id.Choco_checkbox);
        Boolean hasCaramel = caramelCheckBox.isChecked();

        CheckBox chocolateCheckBox= findViewById(R.id.caramel_checkbox);
        Boolean hasChocolate = chocolateCheckBox.isChecked();

        int price =  calculatePrice(hasCaramel, hasChocolate);
        String orderSummary = createOrderSummary(name,price,hasCaramel,hasChocolate);
        displayMessage(orderSummary);

    }

    private String createOrderSummary(String name, int price, Boolean hasCaramel, Boolean hasChocolate) {
        return  name+"\n Шоколад "+hasCaramel+"\n Карамель "+hasChocolate+"\nКол-во : "+quantity+"\nИтог: $"+price+"\nСпасибо за покупку!";
    }

    public boolean addCaramel(View view) {
        CheckBox checkBox = findViewById(R.id.Choco_checkbox);
        boolean isCheckBox = checkBox.isChecked();
        return isCheckBox;
    }

    public boolean addChocolate(View view) {
        CheckBox checkBoxC = findViewById(R.id.caramel_checkbox);
        boolean isCheckBoxC = checkBoxC.isChecked();
        return isCheckBoxC;
    }

    public boolean addPoroh(View view) {
        CheckBox checkBoxA = findViewById(R.id.caramel_checkbox);
        boolean isCheckBoxA = checkBoxA.isChecked();
        return isCheckBoxA;
    }

    public void increment(View view){
        if(quantity < 100) {
            quantity = quantity + 1;
        }
        display(quantity);
    }

    public void decrement(View view){
        if(quantity > 1) {
            quantity = quantity - 1;
        }
        display(quantity);
    }

    private String nameClient() {
        EditText nameClient = findViewById(R.id.NameClient_view);
        Editable nameEditable = nameClient.getText();
        String name = nameEditable.toString();
        return name;
    }

    /**
     * Этот метод отображает заданное значение количества на экране.
     */
    private void display(int number) {
        TextView quantityTextView = findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }

    /**
     * Этот метод отображает заданную цену на экране.
     */
/*    private void displayPrice(int number) {
        TextView priceTextView = (TextView) findViewById(R.id.price_text_view);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
    }*/

    /**
     * Этот метод отображает заданный текст на экране.
     */
    private void displayMessage(String message) {
        TextView orderSummaryTextView = findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);
    }
}